"use client";

import React, { useState, useId } from "react";
import Link from "next/link";

export function MeteringCalculator() {
  const [identities, setIdentities] = useState(280);
  const [events, setEvents] = useState(18800);

  const identitiesId = useId();
  const eventsId = useId();

  const identityPercent = Math.min(100, Math.max(0, (identities / 5000) * 100));
  const eventPercent = Math.min(100, Math.max(0, (events / 250000) * 100));

  const applyPreset = (presetIdentities: number, presetEvents: number) => {
    setIdentities(presetIdentities);
    setEvents(presetEvents);
  };

  return (
    <div className="simulator-card metering-card" aria-label="Illustrative request volume scenario">
      {/* Card Header with Presets */}
      <div className="metering-card-header">
        <div className="metering-header-top">
          <span className="metering-tag">Request volume scenario</span>
          <div className="metering-presets">
            <button
              type="button"
              className={`preset-btn ${identities === 280 && events === 18800 ? "is-active" : ""}`}
              onClick={() => applyPreset(280, 18800)}
            >
              Seed (280)
            </button>
            <button
              type="button"
              className={`preset-btn ${identities === 1200 && events === 85000 ? "is-active" : ""}`}
              onClick={() => applyPreset(1200, 85000)}
            >
              Growth (1.2k)
            </button>
            <button
              type="button"
              className={`preset-btn ${identities === 4500 && events === 200000 ? "is-active" : ""}`}
              onClick={() => applyPreset(4500, 200000)}
            >
              Scale (4.5k)
            </button>
          </div>
        </div>

        <div className="metering-tier">
          <span className="tier-zero" aria-hidden="true">↗</span>
          <div className="tier-text-group">
            <span className="tier-name">Illustrative only</span>
            <span className="tier-subtext">Adjust the sample scale. This is not connected to a runtime or billing plan.</span>
          </div>
        </div>
      </div>

      {/* Main Sliders & Cost Grid */}
      <div className="metering-card-body">
        {/* Sliders Column */}
        <div className="metering-sliders">
          {/* Slider 1: Active Identities */}
          <div className="slider-group">
            <div className="slider-meta">
              <label htmlFor={identitiesId} className="slider-label">
                Active Non-Human Identities (NHIs)
              </label>
              <div className="slider-val-tag">
                <span className="val-number">{identities.toLocaleString()}</span>
                <span className="val-rate">scenario</span>
              </div>
            </div>
            <div className="slider-track-wrap">
              <input
                id={identitiesId}
                type="range"
                min="0"
                max="5000"
                step="10"
                value={identities}
                onChange={(e) => setIdentities(Number(e.target.value))}
                className="cyan-slider"
                style={{
                  background: `linear-gradient(to right, var(--brand-cyan) 0%, var(--brand-cyan) ${identityPercent}%, var(--border-subtle) ${identityPercent}%, var(--border-subtle) 100%)`,
                }}
                aria-valuemin={0}
                aria-valuemax={5000}
                aria-valuenow={identities}
              />
            </div>
          </div>

          {/* Slider 2: Ingested Events */}
          <div className="slider-group">
            <div className="slider-meta">
              <label htmlFor={eventsId} className="slider-label">
                Ingested MCP Tool Events / Month
              </label>
              <div className="slider-val-tag">
                <span className="val-number">{events.toLocaleString()}</span>
                <span className="val-rate">scenario</span>
              </div>
            </div>
            <div className="slider-track-wrap">
              <input
                id={eventsId}
                type="range"
                min="0"
                max="250000"
                step="500"
                value={events}
                onChange={(e) => setEvents(Number(e.target.value))}
                className="cyan-slider"
                style={{
                  background: `linear-gradient(to right, var(--brand-cyan) 0%, var(--brand-cyan) ${eventPercent}%, var(--border-subtle) ${eventPercent}%, var(--border-subtle) 100%)`,
                }}
                aria-valuemin={0}
                aria-valuemax={250000}
                aria-valuenow={events}
              />
            </div>
          </div>

          {/* Scenario summary */}
          <div className="calculator-breakdown">
            <div className="breakdown-item">
              <span>Identity count:</span>
              <span className="item-free">{identities.toLocaleString()}</span>
            </div>
            <div className="breakdown-item">
              <span>Monthly event volume:</span>
              <span>{events.toLocaleString()}</span>
            </div>
            <div className="breakdown-item">
              <span>Pricing estimate:</span>
              <span>Unavailable</span>
            </div>
          </div>
        </div>

        {/* Cost Display Column */}
        <div className="metering-cost-column">
          <span className="cost-label">Commercial status</span>
          <div className="cost-amount-wrap">
            <span className="cost-amount">Preview</span>
          </div>
          <span className="cost-guarantee">No pricing or live usage connection is published.</span>
          <Link href="/benchmarks" className="metering-cta-btn">
            Evidence status <span aria-hidden="true">→</span>
          </Link>
        </div>
      </div>
    </div>
  );
}

