import type { Metadata, Viewport } from "next";
import "@axiom/ui/theme.css";
import "./styles.css";

export const metadata: Metadata = {
  title: { default: "Axiom NHI — Security for AI tool calls", template: "%s · Axiom NHI" },
  description: "An inline security gateway for MCP tool calls. Inspect, validate, and govern non-human identities at the point of execution.",
  openGraph: {
    title: "Axiom NHI — Security for AI tool calls",
    description: "Bring policy enforcement to the MCP runtime boundary.",
    type: "website",
  },
  robots: { index: true, follow: true },
};

export const viewport: Viewport = { colorScheme: "dark light" };

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en" data-theme="dark"><body>{children}</body></html>;
}
