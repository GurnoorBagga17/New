import Link from "next/link";
import { SiteShell } from "./components/SiteShell";
import { EnclaveVisual } from "./components/EnclaveVisual";
import { TerminalSimulator } from "./components/TerminalSimulator";
import { MeteringCalculator } from "./components/MeteringCalculator";
import { ThesisSwitcher } from "./components/ThesisSwitcher";

const capabilities = [
  {
    number: "01",
    badge: "IDENTITY CONTEXT",
    title: "Know which identity is acting",
    body: "Bring non-human identity and resource indicators into the tool-call authorization context. Protocol coverage is reported from the integrated runtime.",
    gradient: "from-cyan-500/10 to-transparent",
  },
  {
    number: "02",
    badge: "ARGUMENT VALIDATION",
    title: "Inspect the call before it reaches a tool",
    body: "Inspect tool-call arguments against configured validators before a policy decision is applied.",
    gradient: "from-indigo-500/10 to-transparent",
  },
  {
    number: "03",
    badge: "CEDAR POLICY",
    title: "Make the decision visible and reviewable",
    body: "Evaluate Cedar policies at the runtime boundary. Latency and enforcement behavior are reported only when supported by verified runtime measurements.",
    gradient: "from-violet-500/10 to-transparent",
  },
  {
    number: "04",
    badge: "AUDIT CONTEXT",
    title: "Keep decision context close to the event",
    body: "Record redacted authorization events with decision context for local inspection. Audit integrity and retention depend on the configured runtime.",
    gradient: "from-emerald-500/10 to-transparent",
  },
];

const ecosystemTools = [
  "Claude Desktop",
  "OpenAI agents",
  "LangChain & LangGraph",
  "AutoGen",
  "CrewAI",
  "OpenBao HSM",
  "Cedar Engine",
];

const kpiMetrics = [
  { value: "Local", label: "Operator console", subtext: "Same-origin interface for a local gateway runtime." },
  { value: "Cedar", label: "Policy studio", subtext: "Author and simulate policy candidates." },
  { value: "Audit", label: "Event explorer", subtext: "Search and export buffered redacted events." },
  { value: "Pending", label: "Runtime evidence", subtext: "Published only with verified run artifacts." },
];

export default function HomePage() {
  return (
    <SiteShell>
      {/* ================= HERO SECTION ================= */}
      <section className="hero-section">
        <div className="wrap hero-layout">
          {/* Left Column: Headlines & Quickstart */}
          <div className="hero-content">
            <div className="hero-live-badge">
              <span className="hero-badge-mark" aria-hidden="true">●</span>
              <span>OPEN SOURCE · INLINE MCP SECURITY</span>
            </div>

            <h1 className="hero-headline">
              Govern the MCP<br />
              tool call at the<br />
              moment it runs.
            </h1>

            <p className="hero-subheadline">
              A local-first MCP gateway that brings identity context, argument validation, and Cedar policy to the tool-call path.
              Explore the operator experience; runtime coverage and benchmark evidence are reported separately.
            </p>

            <div className="hero-actions">
              <Link className="deploy-button" href="/playground">Explore the simulation <span aria-hidden="true">→</span></Link>
              <Link className="text-link-button" href="#architecture">How it fits <span aria-hidden="true">↓</span></Link>
            </div>

            <div className="hero-meta-strip">
              <span className="meta-item"><span className="meta-mark" aria-hidden="true">·</span> Local-first design</span>
              <span className="meta-item"><span className="meta-mark" aria-hidden="true">·</span> Apache-2.0 project</span>
              <span className="meta-item"><span className="meta-mark" aria-hidden="true">·</span> Benchmarks pending</span>
            </div>
          </div>

          {/* Right Column: 3D Isometric Enclave Visual */}
          <div className="hero-visual-wrapper">
            <EnclaveVisual />
          </div>
        </div>
      </section>

      {/* ================= SOCIAL PROOF & ECOSYSTEM STRIP ================= */}
      <section className="ecosystem-strip">
        <div className="wrap ecosystem-inner">
          <span className="ecosystem-lead">EXAMPLE AGENT ECOSYSTEMS · INTEGRATION STATUS VARIES</span>
          <div className="ecosystem-tags">
            {ecosystemTools.map((tool) => (
              <span key={tool} className="ecosystem-tag">
                {tool}
              </span>
            ))}
          </div>
        </div>
      </section>

      {/* ================= DUAL INTERACTIVE CARDS SECTION ================= */}
      <section className="interactive-cards-section" id="simulation">
        <div className="wrap interactive-cards-grid">
          {/* Card 1: Split Terminal & Policy Trace Simulator */}
          <TerminalSimulator />

          {/* Card 2: Illustrative request-volume scenario */}
          <MeteringCalculator />
        </div>
      </section>

      {/* ================= KPI PERFORMANCE BENCHMARK STRIP ================= */}
      <section className="kpi-section">
        <div className="wrap kpi-grid">
          {kpiMetrics.map((kpi) => (
            <div key={kpi.label} className="kpi-card">
              <span className="kpi-value">{kpi.value}</span>
              <h3 className="kpi-label">{kpi.label}</h3>
              <p className="kpi-subtext">{kpi.subtext}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ================= BENTO ENTERPRISE CAPABILITIES ================= */}
      <section className="section wrap" id="runtime">
        <div className="section-heading">
          <p className="eyebrow">DEFENSE-IN-DEPTH ARCHITECTURE</p>
          <h2>One unified inline decision boundary.</h2>
          <p>Axiom’s product focus is the decision boundary between an MCP client and its tool server. The UI makes each stage inspectable; runtime coverage and performance remain subject to integration and verification.</p>
        </div>

        <div className="bento-grid">
          {capabilities.map((item) => (
            <article className="bento-card" key={item.number}>
              <div className="bento-header">
                <span className="bento-badge">{item.badge}</span>
                <span className="bento-number">{item.number}</span>
              </div>
              <h3>{item.title}</h3>
              <p>{item.body}</p>
              <div className="bento-footer">
                <span className="bento-link">
                  Explore Architecture <span aria-hidden="true">↗</span>
                </span>
              </div>
            </article>
          ))}
        </div>
      </section>

      {/* ================= ARCHITECTURE THESIS SWITCHER ================= */}
      <section className="section wrap thesis-section" id="architecture">
        <div className="section-heading">
          <p className="eyebrow">THE NON-HUMAN IDENTITY REVOLUTION</p>
          <h2>Security built for the agent perimeter.</h2>
          <p>
            Identity inventory and lifecycle governance matter across an enterprise. Axiom focuses on the inline MCP request path, where a specific tool call can be inspected against identity context and policy.
          </p>
        </div>
        <ThesisSwitcher />
      </section>

      {/* ================= ENTERPRISE CLOSING CTA ================= */}
      <section className="closing-section">
        <div className="wrap closing-card">
          <div className="closing-content">
            <span className="announcement-pill">PHASE 1 · FRONTEND PREVIEW</span>
            <h2>
              Inspect the decision path before trusting the claim.
            </h2>
            <p>
              Explore the synthetic interaction, review the implementation status, and see which runtime evidence is still pending.
            </p>
            <div className="closing-actions">
              <Link className="deploy-button" href="/playground">
                Explore simulation
              </Link>
              <Link className="text-link-button" href="/benchmarks">
                Evidence status <span aria-hidden="true">→</span>
              </Link>
            </div>
          </div>
          <div className="closing-code-preview preview-module-list">
            <p className="eyebrow">WHAT THIS PREVIEW CONTAINS</p>
            <ul>
              <li><span>01</span><div><strong>Traffic console</strong><small>Stream state, event search, and redacted inspection</small></div></li>
              <li><span>02</span><div><strong>Cedar studio</strong><small>Policy authoring with dry-run and activation boundaries</small></div></li>
              <li><span>03</span><div><strong>Revocation status</strong><small>Disabled until the local revoke endpoint is available</small></div></li>
            </ul>
          </div>
        </div>
      </section>
    </SiteShell>
  );
}

