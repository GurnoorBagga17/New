Axiom NHI Frontend Bundle

Included: gateway operator UI, public web app, shared UI and Cedar editor packages, frontend API contracts, token pipeline, architecture notes, and frontend planning documents.

Requirements: Node.js >= 20 and pnpm >= 9.

Setup from this folder:
  pnpm install

Run the public web app:
  pnpm --filter @axiom/web dev -- --hostname 127.0.0.1 --port 3000

Run the gateway operator UI (in a second terminal):
  pnpm --filter @axiom/gateway-ui dev -- --host 127.0.0.1 --port 3001

The gateway UI dev server proxies /v1/local requests to localhost:8080. Backend routes are not bundled here. Build artifacts, caches, and node_modules are excluded.
